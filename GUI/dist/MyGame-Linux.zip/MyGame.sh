#!/bin/sh
java  -jar MyGame.jar
        